# Hangman game


## How to Load the game

- unzip the Folder and open hangman_game.py

### How to Play the Game

pick letters trying to guess the word that fits the given blanks


### Special Features

when loading the game a new word will be selected at random from the 'words' list
